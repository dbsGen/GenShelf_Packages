require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://www.hheehh.com'

  def parse path
    begin
      doc = XMLDocument.new FileData.new(path), 1
      nodes = doc.xpath("//div[@class='cComicList']//a")
      books = []
      nodes.each do |node|
        book = Book.new
        book.name = node.getContent.strip
        book.subtitle = node.attr('title')
        book.url = HOST_URL + node.attr('href')
        book.thumb = node.getChild(0).attr('src')
        books << book
      end
      no_more = true
      if books.size > 0
        nodes = doc.xpath("(//span[@class='cPageChangeLink'])[1]/a")
        if nodes[2].hasAttribute('href') == 1
          no_more = false
        else
          no_more = true
        end
      end
      yield books, no_more
    rescue Exception => e
      p e
      yield nil
    end
  end

  def main_url page
    type = settings.find '类别'
    type = 0 unless type
    if type == 0
      "#{HOST_URL}/comic/#{page + 1}.html"
    else
      unless @types
        @types = JSON.parse(file('types.json').text).values
      end
      "#{HOST_URL}/comic/class_#{@types[type]}/#{page + 1}.html"
    end
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = main_url(page)
    p url
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        parse c.path do |pages, no_more|
          if pages
            on_complete.inv true, pages, no_more
          else
            on_complete.inv false
          end
        end
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    if page == 0
      client = HTTPClient.new book.url
      client.on_complete = Callback.new do |c|
        if c.getError.length == 0
          doc = XMLDocument.new FileData.new(c.path), 1
          links = doc.xpath("//ul[@class='cVolUl']/li/a")
          des_node = doc.xpath("//div[@id='about_kit']//li[last()]/b/following-sibling::text()").first
          book.des = des_node.getContent
          chapters = []
          links.each do |link|
            chapter = Chapter.new
            chapter.url = HOST_URL + link.attr('href')
            chapter.name = link.getContent[/[^\s]+$/]
            chapters << chapter
          end
          on_complete.inv true, book, chapters, false
        else
          on_complete.invoke [false]
        end
      end
      client.start
      client
    else
      on_complete.inv true, book, [], false
    end
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    begin
      if page == 0
        client = HTTPClient.new "#{HOST_URL}/comic/?act=search&st=#{HTTP::URL::encode key}"
        client.on_complete = Callback.new do |c|
          if c.getError.length == 0
            parse c.path do |pages, no_more|
              if pages
                on_complete.inv true, pages, no_more
              else
                on_complete.inv false
              end
            end
          else
            on_complete.inv false
          end
        end
        client.start
        client
      else

        on_complete.inv true, []
      end
    rescue Exception => e
      on_complete.inv false
    end
  end

end
