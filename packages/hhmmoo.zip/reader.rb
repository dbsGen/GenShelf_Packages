require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  HOST_URL = 'http://manhua.fzdm.com/'
  @stop = false
  @chapter_url

  def servce_num
    ser = settings.find '服务器'
    ser = 0 unless ser
    ser
  end

  def load_page chapter_url, idx, total = 0
    page = Page.new 
    page.url = chapter_url.gsub(/(?<=\/)\d(?=\.html)/, (idx+1).to_s)
    @client = HTTPClient.new page.url
    @client.read_cache = true
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        inputs = doc.xpath("//input[@id]")
        dm_node = doc.xpath("//input[@id='hdDomain']").first
        domains = dm_node.attr('value').split('|')
        img_node = doc.xpath("//img[@id='img1021' or @id='img2391' or @id='img7652' or @id='imgCurr']").first
        name = img_node.attr('name')
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval file('start.js').text
        end
        url = @javascript.eval("unsuan('#{name}')")
        page.picture = domains[servce_num] + url
        if total == 0
          count_node = doc.xpath("//input[@id='hdPageCount']").first
          total = count_node.attr('value').to_i
          on_page_count.inv true, total
        end
        loadedPage idx, true, page
        if idx < total - 1
          load_page chapter_url, idx + 1, total
        end
      else
        loadedPage idx, false, page
        if total == 0
          on_page_count.inv false
        end
      end
    end
    @client.start
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @stop = false
    load_page chapter.url, 0
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0
    @client = HTTPClient.new page.url
    @client.read_cache = false
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        inputs = doc.xpath("//input[@id]")
        dm_node = doc.xpath("//input[@id='hdDomain']").first
        domains = dm_node.attr('value').split('|')
        img_node = doc.xpath("//img[@id='img1021' or @id='img2391' or @id='img7652' or @id='imgCurr']").first
        name = img_node.attr('name')
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval file('start.js').text
        end
        url = @javascript.eval("unsuan('#{name}')")
        page.picture = domains[servce_num] + url
        on_complete.inv true, page
      else
        on_complete.inv false, page
      end
    end
    @client.start
  end
end
