function unsuan(s)
{
    var x = s.substring(s.length-1);
    var w="abcdefghijklmnopqrstuvwxyz";
    var xi=w.indexOf(x)+1;
    var sk = s.substring(s.length-xi-12,s.length-xi-1);
    s=s.substring(0,s.length-xi-12);
	var k=sk.substring(0,sk.length-1);
	var f=sk.substring(sk.length-1);
	for(i=0;i<k.length;i++) {
	    eval("s=s.replace(/"+ k.substring(i,i+1) +"/g,'"+ i +"')");
	}
    var ss = s.split(f);
	s="";
	for(i=0;i<ss.length;i++) {
	    s+=String.fromCharCode(ss[i]);
    }
    return s;
}