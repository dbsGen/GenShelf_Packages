require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'
require 'encoder'


# 主页解析文件
# 必须重载 :load :search 和 :loadBook 三个方法
class Library < HiEngine::Object

  HOST_URL = 'http://www.doujinlife.com'

  @areas = nil
  @types = nil

  def host_url page
    "#{HOST_URL}/page_#{page+1}.html"
  end

  def parseDoc doc
    lis = doc.xpath "//*[@class='allmangalist']/ul/li"
    books = []
    book_name = nil
    lis.each do |li|
      spans = li.xpath('span')
      if spans.size == 1
        book_name = spans[0].getContent
      elsif spans.size >= 3
        book = Book.new
        book.name = book_name
        a_node = spans[0].xpath('a')[0]
        book.url = HOST_URL + a_node.attr('href')
        img_node = a_node.xpath('img')[0]
        book.thumb = HOST_URL + img_node.attr('src')
        tags = []
        arr = spans[2].xpath('a')
        arr.each do |tag|
          tags << tag.getContent.strip
        end
        book.subtitle = tags.join ', '
        books << book
      end
    end
    return books
  end

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = host_url page
    p url
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        books = parseDoc doc
        on_complete.inv true, books
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    chapter = Chapter.new
    chapter.url = book.url
    chapter.name = 'Chapter'
    on_complete.inv true, book, [chapter], true
  end


  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = HOST_URL + "/s/#{HTTP::URL::encode key}/#{page+1}/"
    p url
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        books = parseDoc doc
        on_complete.inv true, books
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
