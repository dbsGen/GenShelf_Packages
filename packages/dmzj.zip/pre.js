var search = {
    renderResult: function (obj) {
        return JSON.stringify(obj);
    }
}