require 'library'
require 'reader'
require 'settings'

$config = {
    library: Library,
    reader: Reader,
    settings: Settings
}
