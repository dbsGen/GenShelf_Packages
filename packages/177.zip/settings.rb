require 'models'

class Settings < HiEngine::Object
  def process
    begin
      item = SettingItem.new
      item.name = '服务器'
      item.type = 1
      item.params = ['中国大陆','海外']
      addItem item

      item = SettingItem.new
      item.name = '类别'
      item.type = 1
      item.params = ['全部','中文成人H漫畫','日文成人H漫畫','全彩CG']
      addItem item

    rescue Exception => e
      p e
    end
  end
end
