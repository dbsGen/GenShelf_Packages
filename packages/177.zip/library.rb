require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://www.177pic.info'
  CN_HOST_URL = 'http://www.177piczz.info'

  def main_url page
    # unless @types
    #   @types = JSON.parse(file('types.json').text).values
    # end
    type = settings.find('类别') || 0
    sev = settings.find('服务器') || 0
    url = if sev == 0
      CN_HOST_URL
    else
      HOST_URL
    end
    
    case type
    when 1
      url << "/html/category/tt"
    when 2
      url << "/html/category/jj"
    when 3
      url << "/html/category/cg"
    end
    
    "#{url}/page/#{page}"
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = main_url(page)
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath("//div[@class='post_box']")
        books = []
        nodes.each do |node|
          book = Book.new
          title_node = node.xpath("div[@class='c-top']/div[@class='tit']/h2[@class='h1']/a").first
          book.url = title_node.attr('href')
          book.name = title_node.getContent
          book.subtitle = book.name
          img_node = node.xpath("div[@class='c-con']/a[@class='disp_a']/img").first
          book.thumb = img_node.attr('src')
          books << book
        end
        no_more = doc.xpath("//a[@rel='next']").size == 0
        on_complete.inv true, books, no_more
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    if page == 0
      chapter = Chapter.new
      chapter.url = book.url
      chapter.name = 'Chapter 1'
      on_complete.inv true, book, [chapter], false
    else
      on_complete.inv false, book
    end
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = "http://www.177pic.info/page/#{page+1}?s=#{HTTP::URL::encode key}"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath("//div[@class='post_box']")
        books = []
        nodes.each do |node|
          book = Book.new
          title_node = node.xpath("div[@class='c-top']/div[@class='tit']/h2[@class='h1']/a").first
          book.url = title_node.attr('href')
          book.name = title_node.getContent
          book.subtitle = book.name
          img_node = node.xpath("div[@class='c-con']/a[@class='disp_a']/img").first
          book.thumb = img_node.attr('src')
          books << book
        end
        no_more = doc.xpath("//a[@rel='next']").size == 0
        on_complete.inv true, books, no_more
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
