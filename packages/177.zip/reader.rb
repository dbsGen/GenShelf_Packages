require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  HOST_URL = 'http://manhua.fzdm.com/'
  @stop = false
  @chapter_url

  def sev_num
    settings.find('服务器') || 0
  end

  def load_p url, max_idx = 0
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1  
        images = doc.xpath("//div[@class='entry-content']/p/img")
        images.each_with_index do |i_node, index|
          page = Page.new
          page.url = url + "##{index}"
          page.picture = i_node.attr('src')
          loadedPage max_idx + index, true, page
        end
        max_idx = max_idx + images.size
        lst_node = doc.xpath("//div[@class='wp-pagenavi']/p/a[last()]").first
        if lst_node && (lst_node.getContent == '下一頁' || lst_node.getContent == '下一页')
          load_p lst_node.attr('href'), max_idx
        elsif max_idx > 0
          on_page_count.inv true, max_idx
        else
          on_page_count.inv false
        end
      else
        on_page_count.inv false
      end
    end
    @client.start
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @stop = false
    load_p chapter.url
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    url = page.url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1  
        images = doc.xpath("//div[@class='entry-content']/p/img")
        idx = url[/\d+$/].to_i
        if images.size > idx
          i_node = images[idx]
          page = Page.new
          page.url = url
          page.picture = i_node.attr('src')
          on_complete.inv true, page
        else
          on_complete.inv false
        end
      else
        on_complete.inv false
      end
    end
    @client.start
  end
end
