require 'models'

class Settings < HiEngine::Object
  def process
    begin
      item = SettingItem.new
      item.name = '类别'
      item.type = 1
      item.params = JSON.parse(file('types.json').text).keys
      addItem item

      item = SettingItem.new
      item.name = '服务器'
      item.type = 1
      item.params = ['服务器1', '服务器2', '服务器3']
      addItem item

    rescue Exception => e
      p e
    end
  end
end
