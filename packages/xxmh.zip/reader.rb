require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  SERVS = ["https://cssh.zgxhxxmh.com/img_v1/cn_svr.aspx", "https://cssh.zgxhxxmh.com/img_v1/hw2_svr.aspx", "https://cssh.zgxhxxmh.com/img_v1/fdc_svr.aspx"]
  @stop = false
  @chapter_url

  def sev_num
    settings.find('服务器') || 0
  end

  def load_p url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        src = doc.xpath("//body//script[not(@src)]")[0].getContent
        
        duktape = DuktapeEngine.new
        duktape.eval src
        img_s = duktape.eval('img_s').to_i
        link_z = duktape.eval('link_z')
        link_z[/colist_(\d+)/]
        cid = $1
        url[/(\d+)\.html[^$]*$/]
        coid = $1
        s_url = "#{SERVS[sev_num]}?s=#{img_s}&cid=#{cid}&coid=#{coid}"
        
        @client = HTTPClient.new s_url
        @client.on_complete = Callback.new do |c|
          @client = nil
          if c.getError.length == 0
            duktape.fileEval c.path
            page_msgs = duktape.eval('msg').split('|')
            sev_url = duktape.eval("img_qianzso[#{img_s}]")
            page_msgs.each_with_index do |p_msg, idx|
              page = Page.new
              page.url = url+"#?page=#{idx+1}"
              page.picture = sev_url + p_msg
              loadedPage idx, true, page
            end
            on_page_count.inv true, page_msgs.size
          else
            on_page_count.inv false
          end
        end
        @client.start
      else
        on_page_count.inv false
      end
    end
    @client.start
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @stop = false
    load_p chapter.url
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    url = page.url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        src = doc.xpath("//body//script").first.attr('src')
        @client = HTTPClient.new src
        @client.on_complete = Callback.new do |c|
          @client = nil
          if c.getError.length == 0
            duktape = DuktapeEngine.new
            duktape.fileEval c.path
            img_s = duktape.eval('img_s').to_i
            link_z = duktape.eval('link_z')
            link_z[/colist_(\d+)/]
            cid = $1
            url[/(\d+)\.html[^$]*$/]
            coid = $1
            s_url = "#{SERVS[sev_num]}?s=#{img_s}&cid=#{cid}&coid=#{coid}"
            @client = HTTPClient.new s_url
            @client.on_complete = Callback.new do |c|
              @client = nil
              if c.getError.length == 0
                duktape.fileEval c.path
                page_msgs = duktape.eval('msg').split('|')
                sev_url = duktape.eval("img_qianzso[#{img_s}]")
                if page_msgs.size > idx
                  page = Page.new
                  page.url = url
                  page.picture = sev_url + page_msgs[idx]
                  on_complete.inv true, page
                else
                  on_complete.inv false
                end
              else
                on_complete.inv false
              end
            end
            @client.start
          else
            on_complete.inv false
          end
        end
        @client.start
      else
        on_complete.inv false
      end
    end
    @client.start
  end
end
