function tu_ding() {}
function tu_shang() {}
function tu_xia() {}
function tu_sui() {}
function xuanfu() {}
var MHW = {
    core: {
        init: function() {},
    },
    suggest: {
        init: function() {}
    },
    viewStat: function() {}
}
var PlayHistoryObj = {
    viewPlayHistory: function() {},
    addPlayHistory: function() {}
}
var $ = function() {
    return function(){};
}
var window = {
    location: {}
}
