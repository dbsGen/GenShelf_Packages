require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://m.57mh.com'

  def main_url page
    unless @area
      types = JSON.parse(file('types.json').text)
      @area = types["area"].values
      @smid = types["smid"].values
      @order = types["order"].values
    end
    at = settings.find('区域') || 0
    st = settings.find('类型') || 0
    ot = settings.find('排序') || 0
    area = if at >= 1 then @area[at-1] else '' end
    smid = if st >= 1 then @smid[st-1] else '' end
    order = @order[ot]
    "#{HOST_URL}/list/area-#{area}-smid-#{smid}-order-#{order}-p-#{page+1}"
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = main_url(page)
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath("//ul[@id='contList']/li/a[@class='bcover']")
        books = []
        nodes.each do |node|
          book = Book.new
          book.url = HOST_URL + node.attr('href')
          book.name = node.attr('title')
          book.subtitle = node.xpath("span[@class='tt']").first.getContent
          book.thumb = node.xpath("img").first.attr('src')
          books << book
        end
        next_nodes = doc.xpath("//span[@class='current next']")
        on_complete.inv true, books, next_nodes.size > 0
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        book.des = doc.xpath("//div[@id='bookIntro']").first.getContent
        nodes = doc.xpath("//div[@id='chapterList']/ul/li/a")
        chapters = []
        nodes.each do |node|
          if node.getContent.size > 0
            chapter = Chapter.new
            chapter.url = HOST_URL + '/' + node.attr('href')
            chapter.name = node.getContent
            chapters << chapter
          end
        end
        on_complete.inv true, book, chapters, false
      else
        on_complete.inv false, book
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = "#{HOST_URL}/search/q_#{HTTP::URL::encode key}"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath("//ul[@id='data_list']/li")
        books = []
        nodes.each do |node|
          book = Book.new
          a_link = node.xpath('a').first
          book.url = HOST_URL + a_link.attr('href')
          book.thumb a_link.xpath('div/img').first.attr('data-src');
          book.name = a_link.xpath('h3').first.getContent
          book.subtitle = a_link.xpath('dl').first.getContent
          books << book
        end
        next_nodes = doc.xpath("//span[@class='current next']")
        on_complete.inv true, books, next_nodes.size > 0
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
