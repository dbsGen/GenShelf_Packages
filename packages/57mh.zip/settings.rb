require 'models'

class Settings < HiEngine::Object
  def process
    begin
      types = JSON.parse(file('types.json').text)

      item = SettingItem.new
      item.name = '区域'
      item.type = 1
      item.params = ['全部'].concat types['area'].keys
      addItem item

      item = SettingItem.new
      item.name = '类别'
      item.type = 1
      item.params = ['全部'].concat types['smid'].keys
      addItem item

      item = SettingItem.new
      item.name = '排序'
      item.type = 1
      item.params = types['order'].keys
      addItem item

      item = SettingItem.new
      item.name = '服务器'
      item.type = 1
      item.params = ['自动', '电信', '联通', '低清']
      addItem item

    rescue Exception => e
      p e
    end
  end
end
