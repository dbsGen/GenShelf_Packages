require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'
require 'encoder'


# 主页解析文件
# 必须重载 :load :search 和 :loadBook 三个方法
class Library < HiEngine::Object

  HOST_URL = 'http://mangapark.me'

  @areas = nil
  @types = nil

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = HOST_URL + "/search?orderby=latest&page=#{page+1}"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//*[@class='manga-list']/div[contains(@class, 'item')]"
        books = []
        nodes.each do |node|
        	book = Book.new
        	link_node = node.xpath("table//a[@class='cover']").first
        	book.url = HOST_URL + link_node.attr('href')
          book.name = link_node.attr('title')
          cover = link_node.xpath('img').first.attr('src')
          unless cover[/https?/]
            cover = 'http:' + cover
          end
          book.thumb = cover
          book.subtitle = node.xpath("(table//div[contains(@class, 'info')]/div[contains(@class, 'field')])[2]/a").first.getContent
        	books << book
        end
        links = doc.xpath("//ul[@class='paging']/li[4]/a")
        on_complete.inv true, books, links.size == 0
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        chapters = []
        nodes = doc.xpath "//ul[@class='chapter']/li"
        nodes.each do |node|
          a_node = node.xpath('span/a').first
        	if a_node
            chapter = Chapter.new
        		chapter.url = HOST_URL + a_node.attr('href')
        		chapter.name = a_node.getContent
            chapters << chapter
        	end
        end
        nb = Book.new
        nb.url = book.url
        nb.name = book.name
        nb.thumb = book.thumb
        nb.subtitle = book.subtitle
        nb.des = doc.xpath("//p[@class='summary']").first.getContent
        on_complete.inv true, nb, chapters, false
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end


  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = HOST_URL + "/search?orderby=latest&page=#{page+1}&q=#{HTTP::URL::encode key}"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//*[@class='manga-list']/div[contains(@class, 'item')]"
        books = []
        nodes.each do |node|
        	book = Book.new
        	link_node = node.xpath("table//a[@class='cover']").first
        	book.url = HOST_URL + link_node.attr('href')
          book.name = link_node.attr('title')
          book.thumb = link_node.xpath('img').first.attr('src')
          book.subtitle = node.xpath("(table//div[contains(@class, 'info')]/div[contains(@class, 'field')])[2]/a").first.getContent
        	books << book
        end
        links = doc.xpath("//ul[@class='paging']/li[3]/a")
        on_complete.inv true, books, links.size == 0
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
