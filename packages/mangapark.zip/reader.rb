require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

# 解析每个章节中的各个page
# 必须重载 :process :stop 和 :reloadPage 三个方法
# 
# @method loadedPage 当process中读取到一页数据时调用。
# @param index int 当前页数从0开始
# @param success bool 是否成功
# @param page Page 读取到的page数据用Page来传递
#
# @property on_page_count Callback 当process中读取到一共有多少页时调用。
# => 成功: on_page_count.inv true, total(int)
# => 失败: on_page_count.inv false
class Reader < HiEngine::Object
  @stop = false
  @chapter_url
  @duktape = nil

  # 开始解析一个章节，读取其中所有的页
  # @param chapter Chapter 章节信息
  def process chapter
    url = chapter.url
    @stop = false

    @client = HTTPClient.new url
    @client.delay = 0.5
    @client.read_cache = true
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        img_node = doc.xpath('//a[@class="img-num"]').first
        total = img_node.getContent[/\w+$/].to_i
        img_url = img_node.attr('href')
        total.times do |i|
          page = Page.new
          page.url = url.gsub(/\w+$/, (i+1).to_s)
          page.picture = img_url.gsub(/(?<=\/)\d+(\.\w+)$/, "#{i+1}#{img_url[/(\.\w+)$/]}")
          loadedPage i, true, page
        end
        self.on_page_count.inv true, total
      else
        self.on_page_count.inv false
      end
    end
    @client.start
    @client
  end

  # 停止解析
  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  # 重新解析一页
  # @param page Page 页信息
  # @param index int 第几页
  # @param on_complete Callback 回调
  # => 成功: on_complete.inv true, new_page(Page) new_page是新的页数据
  # => 失败: on_complete.inv false
  def reloadPage page, idx, on_complete
    @stop = false
    url = page.url
    @stop = false

    @client = HTTPClient.new url
    @client.read_cache = false
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        img_node = doc.xpath('//a[@class="img-num"]').first
        img_url = img_node.attr('href')

        n_page = Page.new
        n_page.url = url
        n_page.picture = img_url
        on_complete.inv true, n_page
      else
        on_complete.inv false, page
      end
    end
    @client.start
    @client
  end
end
