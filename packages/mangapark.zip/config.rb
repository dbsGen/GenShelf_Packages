require 'library'
require 'reader'

$config = {
    library: Library,
    reader: Reader,
    settings: 'settings.json'
}
