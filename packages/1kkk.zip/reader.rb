require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  HOST_URL = 'http://www.1kkk.com'
  @stop = false
  @chapter_url
  @javascript = nil

  def load_picture chapter_url, params, idx, total
    if idx < total
      params[:page] = idx+1
      url = chapterfun_url chapter_url, params
      @client = HTTPClient.new url
      @client.delay = 0.5
      @client.addHeader "Referer", chapter_url
      @client.on_complete = Callback.new do |c|
        @client = nil
        return if @stop
        if c.getError.length == 0
          data = FileData.new(c.path)
          js = data.text
          arr = @javascript.eval(js)
          page = Page.new
          page.status = 1
          page.picture = arr.first
          page.addHeader "Referer", chapter_url
          page.url = url
          loadedPage idx, true, page
          load_picture chapter_url, params, idx+1, total
        else
          loadedPage idx, false, nil
        end
      end
      @client.start
    end
  end

  def chapterfun_url chapter_url, params
    arr = []
    params.each do |k, v|
      arr << "#{k}=#{HTTP::URL::encode v.to_s}"
    end
    "#{chapter_url}chapterfun.ashx?" + (arr.join('&'))
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @chapter_url = chapter.url
    @stop = false

    @client = HTTPClient.new @chapter_url
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval 'window=this;'
          @javascript.eval file("hook.js").text
        end

        key = doc.xpath("//input[@id='dm5_key']")[0].attr('value');
        script = doc.xpath("//script[not(@src)]")[0].getContent
        @javascript.eval(script)
        total_page = @javascript.eval('DM5_IMAGE_COUNT')
        params = {
          cid: @javascript.eval('DM5_CID'),
          page: 1,
          key: mkey,
          language: 1,
          gtk: 6,
          _cid: @javascript.eval('DM5_CID'),
          _mid: @javascript.eval('DM5_MID'),
          _dt: @javascript.eval('DM5_VIEWSIGN_DT'),
          _sign: @javascript.eval('DM5_VIEWSIGN')
        }

        load_picture @chapter_url, params, 0, total_page
        on_page_count.inv true, total_page
      else
        on_page_count.inv false
      end
    end
    @client.start
    @client
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0

    url = page.url
    @client = HTTPClient.new url
      @client.delay = 0.5
      @client.addHeader "Referer", url.gsub(/[^\/]+$/, '')
      @client.on_complete = Callback.new do |c|
        @client = nil
        return if @stop
        if c.getError.length == 0
          data = FileData.new(c.path)
          js = data.text
          arr = @javascript.eval(js)
          page = Page.new
          page.status = 1
          page.picture = arr.first
          page.addHeader "Referer", @chapter_url
          page.url = url
          on_complete.inv true, page
        else
          on_complete.inv false, page
        end
      end
      @client.start
      @client
  end
end
