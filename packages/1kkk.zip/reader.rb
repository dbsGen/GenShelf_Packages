require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  HOST_URL = 'http://www.1kkk.com'
  @stop = false
  @chapter_url
  @javascript = nil

  def load_picture cid, key, idx, total
    if idx < total
      url = "#{@chapter_url}imagefun.ashx?cid=#{cid}&page=#{idx+1}&key=#{key}&maxcount=10"
      @client = HTTPClient.new url
      @client.delay = 0.5
      @client.addHeader "Referer", @chapter_url
      @client.on_complete = Callback.new do |c|
        @client = nil
        return if @stop
        if c.getError.length == 0
          data = FileData.new(c.path)
          js = data.text
          arr = @javascript.eval(js)
          page = Page.new
          page.status = 1
          page.picture = arr.first
          page.addHeader "Referer", @chapter_url
          page.url = url
          loadedPage idx, true, page
          load_picture cid, key, idx + 1, total
        else
          loadedPage idx, false, nil
        end
      end
      @client.start
    end  
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @chapter_url = chapter.url
    @stop = false

    @client = HTTPClient.new @chapter_url
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        cid = @chapter_url[/(\d+)(?=\/$)/]
        unless @javascript
          @javascript = DuktapeEngine.new 
          @javascript.eval 'window=this;'
          @javascript.eval file("hook.js").text
        end

        next_node = doc.xpath("//body/input[@id='dm5_key']/following-sibling::*[1]").first
        dmkey = ""
        if next_node.getName == "script"
          p "content #{next_node.getContent}"
          @javascript.eval next_node.getContent
          dmkey = @javascript.eval "dmkey"
          p "key : #{dmkey}"
        end

        total_page = doc.xpath("//*[@class='zf40']/span[not(@id)]").first.getContent.to_i
        p "total count #{total_page}"
        load_picture cid, key, 0, total_page
        on_page_count.inv true, total_page
      else
        on_page_count.inv false
      end
    end
    @client.start
    @client
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0
    
    url = page.url
    @client = HTTPClient.new url
      @client.delay = 0.5
      @client.addHeader "Referer", url.gsub(/[^\/]+$/, '')
      @client.on_complete = Callback.new do |c|
        @client = nil
        return if @stop
        if c.getError.length == 0
          data = FileData.new(c.path)
          js = data.text
          arr = @javascript.eval(js)
          page = Page.new
          page.status = 1
          page.picture = arr.first
          page.addHeader "Referer", @chapter_url
          page.url = url
          on_complete.inv true, page
        else
          on_complete.inv false, page
        end
      end
      @client.start
      @client
  end
end
