var dmkey;
var $ = function(n) {
	return {
		val: function(val) {
			dmkey = val;
		}
	}
};