require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Library < HiEngine::Object

  HOST_URL = 'http://www.1kkk.com'

  @areas = nil
  @types = nil
  @javascript = nil

  def home_url page
    arr = ['manhua', 'list']
    i = settings.find('剧情')
    case i
    when 1
      arr << 'cg39'
    when 2
      arr << 'cg40'
    when 3
      arr << 'cg41'
    when 4
      arr << 'cg42'
    when 5
      arr << 'cg43'
    when 6
      arr << 'cg44'
    when 7
      arr << 'cg45'
    when 8
      arr << 'cg47'
    when 9
      arr << 'cg55'
    else
    end
    i = settings.find('地区')
    case i
    when 1
      arr << 'area35'
    when 2
      arr << 'area36'
    when 3
      arr << 'area37'
    when 4
      arr << 'area52'
    else
    end
    i = settings.find('完结状态')
    case i
    when 1
      arr << 'st1'
    when 2
      arr << 'st2'
    else
    end
    i = settings.find('排序')
    case i
    when 1
      arr << 's8'
    when 2
      arr << 's10'
    when 3
      arr << 's4'
    when 4
      arr << 's6'
    when 5
      arr << 's12'
    else
    end
    if page > 0
      arr << "p#{page+1}"
    end
    "#{HOST_URL}/#{arr.join '-'}/"
  end

  def search_url page, key
    arr = []
    arr << "page=#{page+1}"
    i = settings.find('剧情')
    case i
    when 1
      arr << 'cg=39'
    when 2
      arr << 'cg=40'
    when 3
      arr << 'cg=41'
    when 4
      arr << 'cg=42'
    when 5
      arr << 'cg=43'
    when 6
      arr << 'cg=44'
    when 7
      arr << 'cg=45'
    when 8
      arr << 'cg=47'
    when 9
      arr << 'cg=55'
    else
    end
    i = settings.find('地区')
    case i
    when 1
      arr << 'area=35'
    when 2
      arr << 'area=36'
    when 3
      arr << 'area=37'
    when 4
      arr << 'area=52'
    else
    end
    i = settings.find('完结状态')
    case i
    when 1
      arr << 'st=1'
    when 2
      arr << 'st=2'
    else
    end
    i = settings.find('排序')
    case i
    when 1
      arr << 'sort=8'
    when 2
      arr << 'sort=10'
    when 3
      arr << 'sort=4'
    when 4
      arr << 'sort=6'
    when 5
      arr << 'sort=12'
    else
    end
    arr << "title=#{HTTP::URL::encode key}"

    "#{HOST_URL}/search?#{arr.join '&'}"
  end

  def parseDoc doc
    nodes = doc.xpath "//ul[contains(@class, 'mh-list')]//div[@class='mh-item-tip']"
    books = []
    nodes.each do |node|
      begin
        book = Book.new
        a_node = node.xpath('a')[0];
        book.url = HOST_URL + a_node.attr('href')
        book.name = a_node.attr('title')
        cover_node = a_node.xpath("p")[0]
        book.thumb = cover_node.attr('style')[/(?<=url\()[^\)]+/]
        author_node = node.xpath("div/p[@class='author']/span[last()]")[0]
        book.subtitle = author_node.getContent
        des_node = node.xpath("div/div[@class='desc']")[0]
        book.des = des_node.getContent.strip
        books << book
      rescue Exception => e
        p "Error when parse book #{e}"
      end
    end
    books
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete

    url = home_url page
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        on_complete.inv true, parseDoc(doc)
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        chapters = []
        cs_nodes = doc.xpath "//ul[contains(@class, 'view-win-list')]"
        cs_nodes.each do |c_node|
          nodes = c_node.xpath('li/a')
          nodes.each do |node|
            chapter = Chapter.new
            chapter.name = node.getContent.strip
            chapter.url = HOST_URL + node.attr('href')
            chapters << chapter
          end
        end

        nb = Book.new
        nb.url = book.url
        nb.name = book.name
        nb.thumb = book.thumb
        nb.subtitle = book.subtitle
        nb.des = doc.xpath("//div[@class='info']/p[@class='content']").first.getContent.strip
        on_complete.inv true, nb, chapters, false
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = search_url page, key
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        data = FileData.new(c.path)
        doc = XMLDocument.new data, 1
        on_complete.inv true, parseDoc(doc)
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
