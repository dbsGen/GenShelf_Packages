require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Library < HiEngine::Object

  HOST_URL = 'http://www.1kkk.com'
  
  @areas = nil
  @types = nil
  @javascript = nil

  def home_url page
    arr = ['manhua', 'list']
    i = settings.find('剧情')
    case i
    when 1
      arr << 'cg39'
    when 2
      arr << 'cg40'
    when 3
      arr << 'cg41'
    when 4
      arr << 'cg42'
    when 5
      arr << 'cg43'
    when 6
      arr << 'cg44'
    when 7
      arr << 'cg45'
    when 8
      arr << 'cg47'
    when 9
      arr << 'cg55'
    else
    end
    i = settings.find('地区')
    case i
    when 1
      arr << 'area35'
    when 2
      arr << 'area36'
    when 3
      arr << 'area37'
    when 4
      arr << 'area52'
    else
    end
    i = settings.find('完结状态')
    case i
    when 1
      arr << 'st1'
    when 2
      arr << 'st2'
    else
    end
    i = settings.find('排序')
    case i
    when 1
      arr << 's8'
    when 2
      arr << 's10'
    when 3
      arr << 's4'
    when 4
      arr << 's6'
    when 5
      arr << 's12'
    else
    end
    if page > 0
      arr << "p#{page+1}"
    end
    "#{HOST_URL}/#{arr.join '-'}/"
  end

  def search_url page, key
    arr = []
    arr << "page=#{page+1}"
    i = settings.find('剧情')
    case i
    when 1
      arr << 'cg=39'
    when 2
      arr << 'cg=40'
    when 3
      arr << 'cg=41'
    when 4
      arr << 'cg=42'
    when 5
      arr << 'cg=43'
    when 6
      arr << 'cg=44'
    when 7
      arr << 'cg=45'
    when 8
      arr << 'cg=47'
    when 9
      arr << 'cg=55'
    else
    end
    i = settings.find('地区')
    case i
    when 1
      arr << 'area=35'
    when 2
      arr << 'area=36'
    when 3
      arr << 'area=37'
    when 4
      arr << 'area=52'
    else
    end
    i = settings.find('完结状态')
    case i
    when 1
      arr << 'st=1'
    when 2
      arr << 'st=2'
    else
    end
    i = settings.find('排序')
    case i
    when 1
      arr << 'sort=8'
    when 2
      arr << 'sort=10'
    when 3
      arr << 'sort=4'
    when 4
      arr << 'sort=6'
    when 5
      arr << 'sort=12'
    else
    end
    arr << "title=#{HTTP::URL::encode key}"

    "#{HOST_URL}/search?#{arr.join '&'}"
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete

    url = home_url page
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//ul[@class='in_01']/li/p[@class='cover']"
        books = []
        nodes.each do |node|
          children = node.getChildren
          begin
            book = Book.new
            a_node = children[0];
            book.url = HOST_URL + a_node.attr('href')
            book.name = a_node.getContent.strip
            img = a_node.xpath('img').first
            book.thumb = img.attr('src')
            book.subtitle = children[1].getContent
            books << book
          rescue Exception => e
            p "Error when parse book #{e}"
          end
        end
        on_complete.inv true, books
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        chapters = []
        cs_nodes = doc.xpath "//ul[contains(@class, 'sy_nr1')]"
        chapters_node = nil
        node_type = 0
        cs_nodes.each do |cs_node|
          title_node = cs_node.xpath("preceding-sibling::div[contains(@class, 'sy_bt')][1]/h3").first
          if title_node.getContent["全部"] 
            chapters_node = cs_node
            node_type = 1
          elsif title_node.getContent["最新"] and chapters_node == nil
            chapters_node = cs_node
            node_type = 2
          end
        end
        if node_type != 0
          cs = chapters_node.xpath("li/a")
          if node_type == 1
            cs.reverse_each do |node|
              chapter = Chapter.new
              chapter.name = node.getContent.strip
              chapter.url = HOST_URL + node.attr('href')
              chapters << chapter
            end
          elsif node_type == 2
            cs.each do |node|
              chapter = Chapter.new
              chapter.name = node.getContent.strip
              chapter.url = HOST_URL + node.attr('href')
              chapters << chapter
            end
          end
        end

        nb = Book.new
        nb.url = book.url
        nb.name = book.name
        nb.thumb = book.thumb
        nb.subtitle = book.subtitle
        nb.des = doc.xpath("//li[@class='mt10 z555']/b/following-sibling::text()").first.getContent.strip
        on_complete.inv true, nb, chapters, false
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = search_url page, key
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        data = FileData.new(c.path)
        doc = XMLDocument.new data, 1
        nodes = doc.xpath "//div[@class='tk']"
        nodes = nodes.drop 1
        books = []
        nodes.each do |node|
          begin
            children = node.getChildren
            book = Book.new
            tk1 = children[0]
            book.thumb = tk1.getChild(0).attr 'src'
            book.url = HOST_URL + tk1.getChild(2).attr('href')
            tk2 = children[1]
            book.subtitle = tk2.xpath("ul[@class='tk_02_nr']/li/a").first.getContent
            book.name = tk2.xpath("div[contains(@class, 'tk_02_bt')]/h1").first.getContent.strip
            book.des = children[4].xpath("b/following-sibling::text()").first.getContent.strip
            books << book
          rescue Exception => e
            p "Error when parse book #{e}"
          end
        end
        last = doc.xpath("//div[@id='search_fy']/*[last()]").first
        no_more = books.size == 0
        if last == nil
          no_more = true
        elsif last.attr('class') == 'current'
        	no_more = true
        end
        on_complete.inv true, books, no_more
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
