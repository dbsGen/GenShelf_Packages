require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  @stop = false
  @chapter_url

  def js_engine
    unless @javascript
      @javascript = DuktapeEngine.new
    end
    return @javascript
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @stop = false
    url = chapter.url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      doc = XMLDocument.new FileData.new(c.path), 1
      ss = doc.xpath('//script[not(@src)]')
      ss.each do |script|
        js_engine.eval(script.getContent)
      end
      pages = js_engine.eval('newImgs')
      pages.each_with_index do |p_path, idx|
        page = Page.new
        page.url = url
        page.picture = p_path
        p p_path
        page.addHeader "Referer", url
        loadedPage idx, true, page
      end
      on_page_count.inv true, pages.size
    end
    @client.start
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    @client = HTTPClient.new SERVS_URL 
    @client.on_complete = Callback.new do |c|
      js_engine.eval(FileData.new(c.path).text)
      page_url = page.url.gsub(/\?[^\?]+$/, '')
      @client = HTTPClient.new page.url
      @client.on_complete = Callback.new do |c|
        doc = XMLDocument.new FileData.new(c.path), 1
        ss = doc.xpath('//script[not(@src)]')
        ss.each do |script|
          js_engine.eval(script.getContent)
        end
        pages = js_engine.eval('cInfo.fs')
        server = js_engine.eval("pageConfig.host.#{sev_name}[0]")
        
        if server and pages
          page = Page.new
          page.url = page_url + "?p=#{idx+1}"
          page.picture = "http://#{server}#{pages[idx]}"
          on_complete.inv true, page
        else 
          on_complete.inv false
        end
      end
      @client.start
    end
    @client.start
    @client
  end
end
