require 'models'

class Settings < HiEngine::Object
  def process
    begin
      types = JSON.parse(file('types.json').text)

      item = SettingItem.new
      item.name = '排序'
      item.type = 1
      item.params = types['sort'].keys
      addItem item

      item = SettingItem.new
      item.name = '连载状态'
      item.type = 1
      item.params = types['status'].keys
      addItem item

    rescue Exception => e
      p e
    end
  end
end
