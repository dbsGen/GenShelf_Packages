require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://manhuaren.com'
  PAGE_SIZE = 21

  def main_url
    "#{HOST_URL}/manhua-list/dm5.ashx"
  end

  def sort_values
    unless @sort
      types = JSON.parse(file('types.json').text)
      @sort = types["sort"].values
      @status = types["status"].values
    end
    return @sort
  end

  def status_values
    unless @status
      types = JSON.parse(file('types.json').text)
      @sort = types["sort"].values
      @status = types["status"].values
    end
    return @status
  end

  def req_body page
    sort = sort_values[settings.find('排序') || 0]
    status = status_values[settings.find('连载状态') || 0]
    "action=getclasscomics&pageindex=#{page + 1}&pagesize=#{PAGE_SIZE}&categoryid=0&tagid=0&status=#{status}&usergroup=0&pay=-1&areaid=0&sort=#{sort}&iscopyright=0"
  end

  def seaarch_body key, page
    "t=7&pageindex=#{page + 1}&f=0&title=#{HTTP::URL::encode key}"
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    client = HTTPClient.new main_url
    client.body = Data.fromString(req_body page)
    client.method = "POST"
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        json = JSON.parse(FileData.new(c.path).text)
        items = json['UpdateComicItems']
        books = []
        items.each do |item|
          book = Book.new
          book.url = "#{HOST_URL}/#{item['UrlKey']}"
          book.name = item["Title"]
          book.subtitle = item["Content"]
          book.thumb = item["ShowPicUrlB"]
          books << book
        end
        on_complete.inv true, books, items.size >= PAGE_SIZE
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1

        book.des = doc.xpath("//*[@class='detail-desc']").first.getContent
        nodes = doc.xpath("//ul[@id='detail-list-select-1']/li/a")
        chapters = []
        nodes.each do |node|
          if node.getContent.size > 0
            chapter = Chapter.new
            chapter.url = HOST_URL + node.attr('href')
            chapter.name = node.getContent
            chapters << chapter
          end
        end
        on_complete.inv true, book, chapters, false
      else
        on_complete.inv false, book
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    client = HTTPClient.new "#{HOST_URL}/pagerdata.ashx"
    client.body = Data.fromString(seaarch_body key, page)
    client.method = "POST"
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        items = JSON.parse(FileData.new(c.path).text)
        books = []
        items.each do |item|
          book = Book.new
          book.url = "#{HOST_URL}#{item['Url']}"
          book.name = item["Title"]
          book.subtitle = item["Content"]
          book.thumb = item["BigPic"]
          books << book
        end
        on_complete.inv true, books, items.size >= PAGE_SIZE
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
