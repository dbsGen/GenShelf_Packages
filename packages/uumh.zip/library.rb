require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'encoder'

class Library < HiEngine::Object

  HOST_URL = 'http://www.uuumh.com'

  def parse path
    doc = XMLDocument.new FileData.new(path), 1
    books = []
    nodes = doc.xpath "//*[@id='listBox']"
    nodes.each do |node|
      book = Book.new
      link_node = node.xpath("div[@class='listBoxTop']/div[@class='listBoxTitle']//a").first
      book.url = HOST_URL + link_node.attr('href')
      book.name = link_node.attr('title').gsub(/<[^>]+>/, '')
      image_node = node.xpath("div[@class='listBoxCenter']//img").first

      book.thumb = image_node.attr('src') if image_node
      begin
        book.subtitle = node.xpath("div[@class='listBoxBottom']/*[@class='listBoxBottomTag']").first.getContent.strip.gsub('标签：', '')
      rescue Exception => e
        p e
      end
      books << book
    end

    last_page = doc.xpath("//*[@class='pages']//li[last()]").first
    no_more = !last_page or last_page.getContent.strip != '下一页'
    yield true, books, no_more
  end

  def host_url page
    unless @types
      @types = [['manhua', 1], ['shaonv', 2], ['huoyingrenzhe', 5], ['sishen', 6], ['haizeiwang', 7]]      
    end
    t = settings.find('类别') || 0
    p "t is #{t}"
    st = @types[t]
    "#{HOST_URL}/#{st[0]}/list_#{st[1]}_#{page+1}.html"
  end

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = host_url(page)

    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
      	parse c.path do |success, books, no_more|
        	on_complete.inv success, books, no_more
      	end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client
  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    chapter = Chapter.new 
    chapter.url = book.url
    chapter.name = "Chapter"

    client = HTTPClient.new chapter.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        content_node = doc.xpath("//div[@class='content']").first
        book.des = content_node.getContent.strip
        on_complete.inv true , book, [chapter], false
      else
        on_complete.inv false
      end
    end
    client.start
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete

    url = "#{HOST_URL}/plus/search.php?keyword=#{Encoder::urlEncodeWithEncoding key, "gbk"}&searchtype=titlekeyword&PageNo=#{page+1}"
    
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        parse c.path do |success, books, no_more|
        	on_complete.inv success, books, no_more
        end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

end
