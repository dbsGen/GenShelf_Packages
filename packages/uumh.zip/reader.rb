require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  @stop = false

  def load_page url, idx, total
    pic_str = "_#{idx+1}.html"
    if idx == 0
      pic_str = ".html"
    end
    p_url = url.gsub(/(_\w+)?\.html/, pic_str)
    @client = HTTPClient.new p_url
    @client.read_cache = true
    @client.delay = 1
    @client.on_complete = Callback.new do |c| 
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        if total == 0
          pages_node = doc.xpath("//div[@class='dede_pages']//li[1]").first
          total = pages_node.getContent[/\w+/].to_i
          on_page_count.inv true, total
        end

        img_node = doc.xpath("//div[@class='content']/img").first
        page = Page.new
        page.url = p_url
        page.picture = img_node.attr('src')
        loadedPage idx, true, page

        if idx < total-1
          load_page url, idx + 1, total
        end

      else
        if total == 0
          on_page_count.inv false
        end
        page = Page.new
        page.url = p_url
        loadedPage idx, false, page
      end
    end
    @client.start
  end

  def process chapter
    @stop = false

    url = chapter.url
    load_page url, 0, 0
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    url = page.url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        img_node = doc.xpath("//div[@class='content']/img").first

        page = Page.new
        page.url = url
        page.picture = img_node.attr('src')
        on_complete.inv true, page
      else
        on_complete.inv false
      end
    end
    @client.start
  end
end
