
var nozomi = null;

function getData(page, size) {
    if (!nozomi) {
        var jspack = new JSPack();
        var total = db_data.length/4; 
        nozomi = jspack.Unpack(total+"I", db_data);
    }
    var from = page * size, end = Math.min(from + size, nozomi.length);
    if (from >= end) {
        return [];
    }else {
        return nozomi.slice(from, end);
    }
}