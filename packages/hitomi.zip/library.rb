require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'gumbo'
require 'duktape'
require 'encoder'


# 主页解析文件
# 必须重载 :load :search 和 :loadBook 三个方法
class Library < HiEngine::Object

  HOST_URL = 'https://hitomi.la'
  DB_URL = 'https://ltn.hitomi.la/index-all.nozomi'

  @areas = nil
  @types = nil

  @db_size

  def js_engine
    unless @js
      @js = DuktapeEngine.new
      @js.evalData file('lib_prepare.js')
      @js.evalData file('jspack.js')
    end
    @js
  end

  def request_blocks blocks, idx = 0, results = [], &block
    id = blocks[idx]
    url = "https://ltn.hitomi.la/galleryblock/#{id}.html"
    client = HTTPClient.new url
    client.read_cache = true
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = GBDocument.new FileData.new(c.path)
        link_node = doc.css("h1 > a").first
        book = Book.new
        book.url = HOST_URL + link_node.attr('href')
        book.name = link_node.getContent
        book.thumb = 'https:' + doc.css(".dj-img1 > img").first.attr('src')
        book.subtitle = doc.css('.dj-desc').first.getContent
        results << book
        if idx + 1 < blocks.size
          request_blocks blocks, idx + 1, results, &block
        else
          block.call true, results
        end
      else
        block.call false
      end
    end
    client.start
  end

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    unless @db_size
      client = HTTPClient.new DB_URL
      client.read_cache = true
      client.on_complete = Callback.new do |c|
        if c.getError.length == 0
          js_engine.setGlobal 'db_data', FileData.new(c.path)
          arr = js_engine.eval("getData(#{page}, 13)")
          request_blocks arr do |suc, books|
            if suc
              on_complete.inv true, books
            else
              on_complete.inv false
            end
          end
        else
          on_complete.inv false
        end
      end
      client.start
    end
    # client = HTTPClient.new url
    # client.on_complete = Callback.new do |c|
    #   if c.getError.length == 0
    #     doc = XMLDocument.new FileData.new(c.path), 1
    #     nodes = doc.xpath "//div[@class='gallery-content']/div"
    #     books = []
    #     nodes.each do |node|
    #     	book = Book.new
    #     	link_node = node.xpath("h1/a").first
    #     	book.url = HOST_URL + link_node.attr('href')
    #       book.name = link_node.getContent
    #       book.thumb = 'https:' + node.xpath("a/div[@class='dj-img-cont']//img[1]").first.attr('src')
    #       book.subtitle = node.xpath("div[@class='dj-content']/table/tr[3]/td[2]").first.getContent
    #     	books << book
    #     end
    #     on_complete.inv true, books, false
    #   else
    #     on_complete.inv false
    #   end
    # end
    # client.start
    # client
  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    chapter = Chapter.new
    chapter.url = book.url.gsub(/\w+(?=\/[^\/]+$)/, 'reader')
    chapter.name = "Chapter 1"
    on_complete.inv true, book, [chapter], false
  end


  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    t = settings.find('Search Type')
    t = 0 unless t
    tv = if t == 0
      'artist'
    elsif t == 1
      'series'
    else
      'character'
    end
    url = HOST_URL + "/#{tv}/#{HTTP::URL::encode key}-all-#{page+1}.html"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//div[@class='gallery-content']/div"
        books = []
        nodes.each do |node|
        	book = Book.new
        	link_node = node.xpath("h1/a").first
        	book.url = HOST_URL + link_node.attr('href')
          book.name = link_node.getContent
          book.thumb = 'https:' + node.xpath("a/div[@class='dj-img-cont']//img[1]").first.attr('src')
          book.subtitle = node.xpath("div[@class='dj-content']/table/tr[3]/td[2]").first.getContent
        	books << book
        end
        on_complete.inv true, books, false
      else
        on_complete.inv true, [], true
      end
    end
    client.start
    client
  end

end
