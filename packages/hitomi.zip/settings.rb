require 'models'

class Settings < HiEngine::Object
  
  def process
    begin
      item = SettingItem.new
      item.name = 'Search Type'
      item.type = 1
      item.params = [
        'Artists',
        'Series',
        'Characters'
      ]
      addItem item

      @login_item = SettingItem.new
      @login_item.name = 'All Artists'
      @login_item.type = 7
      @login_item.params = Callback.new do
        openWebView('https://tn.hitomi.la/allartists-a.html', 'All Allartists', nil)
      end
      addItem @login_item

      @login_item = SettingItem.new
      @login_item.name = 'All Series'
      @login_item.type = 7
      @login_item.params = Callback.new do
        openWebView('https://tn.hitomi.la/allseries-a.html', 'All Series', nil)
      end
      addItem @login_item

      @login_item = SettingItem.new
      @login_item.name = 'All Characters'
      @login_item.type = 7
      @login_item.params = Callback.new do
        openWebView('https://tn.hitomi.la/allcharacters-a.html', 'All Characters', nil)
      end
      addItem @login_item
    rescue Exception => e
      p e

    end
  end
end
