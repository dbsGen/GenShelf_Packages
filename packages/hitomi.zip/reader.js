var images = [];
var display;
var curPanel = 1;
var number_of_images;
var numThin = 0;
var portrait = false;
var goofy_enabled = false;

//this is duplicated in download.js!
var number_of_frontends = 2;
function subdomain_from_galleryid(g) {
        return String.fromCharCode(97 + (g % number_of_frontends));
}
function subdomain_from_url(url, base) {
        var retval = 'a';
        if (base) {
                retval = base;
        }
        
        var r = /\/(\d+)\//;
        var m = r.exec(url);
        var g;
        if (m) {
                g = parseInt(m[1]);
        }
        if (g) {
                retval = subdomain_from_galleryid(g) + retval;
        }
        
        return retval;
}
function url_from_url(url, base) {
        return url.replace(/\/\/..?\.hitomi\.la\//, '//'+subdomain_from_url(url, base)+'.hitomi.la/');
}
