require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Library < HiEngine::Object

  HOST_URL = 'https://www.manhuagui.com'
  
  @areas = nil
  @types = nil
  @javascript = nil

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    area = settings.find '地区'
    type = settings.find '剧情'
    process = settings.find '进度'
    appends = []
    unless @areas
      @areas = file('areas').text.split '|'
    end
    unless @types
      @types = file('types').text.split '|'
    end
    if area != nil and area > 0 and area <= @areas.size
      appends << @areas[area-1]
    end
    if type != nil and type > 0 and type <= @types.size
      appends << @types[type-1]
    end
    if process != nil and process > 0 and type <= 2
      appends << if process == 1 then 'lianzai' else 'wanjie' end
    end

    url = HOST_URL + "/list/#{if appends.size == 0 then '' else "#{appends.join '_'}/" end}update_p#{page+1}.html"
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//ul[@id='contList']/li"
        books = []
        nodes.each do |node|
          children = node.getChildren
          begin
            a_node = children[0];
            book = Book.new
            book.url = HOST_URL + a_node.attr('href')
            book.name = a_node.attr('title')
            img = a_node.xpath('img').first
            book.thumb = img.attr('src')
            if !book.thumb || book.thumb.length == 0
              book.thumb = img.attr('data-src')
            end
            book.subtitle = children[2].getContent
            books << book
          rescue Exception => e
            p "Error when parse book #{e}"
          end
        end
        on_complete.inv true, books
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    client = HTTPClient.new book.url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        chapters = []
        lists = doc.xpath "//div[contains(@class, 'chapter-list')]"
        if lists.size == 0
          view_node = doc.xpath("//input[@id='__VIEWSTATE']").first
          if view_node
            
            unless @javascript
              @javascript = DuktapeEngine.new 
              @javascript.eval 'window=this;'
              @javascript.eval file('lzstring.txt').text
            end
            res = @javascript.eval("LZString.decompressFromBase64(\"#{view_node.attr 'value'}\")")
            b_doc = XMLDocument.new Data::fromString(res), 1
            lists = b_doc.xpath "//div[contains(@class, 'chapter-list')]"
          end
        end
        lists.each do |list|
          blocks = list.xpath 'ul'
          size = blocks.size
          size.times do |i|
            block = blocks[size - i - 1]
            nodes = block.xpath('li/a')
            nodes.each do |node| 
              chapter = Chapter.new
              chapter.url = HOST_URL + node.attr('href')
              chapter.name = node.attr('title')
              chapters << chapter
            end
          end
        end
        nb = Book.new
        nb.url = book.url
        nb.name = book.name
        nb.thumb = book.thumb
        nb.subtitle = book.subtitle
        nb.des = doc.xpath("//div[@id='intro-all']").first.getContent
        on_complete.inv true, nb, chapters, false
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = HOST_URL + "/s/#{HTTP::URL::encode key}_p#{page+1}.html"
    p url
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath "//div[@class='book-result']//li[@class='cf']"
        books = []
        nodes.each do |node|
          begin
            a_node = node.xpath("div[@class='book-cover']/a").first;
            book = Book.new
            book.url = HOST_URL + a_node.attr('href')
            book.name = a_node.attr('title')
            img = a_node.xpath('img').first
            book.thumb = img.attr('src')
            if !book.thumb || book.thumb.length == 0
              book.thumb = img.attr('data-src')
            end
            book.des = node.xpath("div[@class='book-detail']//dd[@class='intro']").first.getContent.gsub('简介：', '')
            books << book
          rescue Exception => e
            p "Error when parse book #{e}"
          end
        end
        last = doc.xpath("//div[@id='AspNetPagerResult']/*[last()]").first
        no_more = books.size == 0
        if last == nil
          no_more = true
        elsif last.attr('class') == 'current'
        	no_more = true
        end
        on_complete.inv true, books, no_more
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

end
