require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  @stop = false
  @chapter_url
  @javascript = nil
  SERVER_LIST = ['i', 'dx', 'lt']

  def host_url
    ser = settings.find('地区') || 0
    "http://#{SERVER_LIST[ser]}.hamreus.com"
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @chapter_url = chapter.url
    @stop = false

    @client = HTTPClient.new @chapter_url
    @client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval 'window=this;'
          @javascript.eval file('lzstring.txt').text
          @javascript.eval file('utils.js').text
        end
        s_node = doc.xpath("//body/script[not(@src)]").first
        @javascript.eval s_node.getContent
        base_path = host_url + @javascript.eval("encodeURI(cInfo.path)")
        files = @javascript.eval "cInfo.files"
        i = 0
        files.each do |file|
          page = Page.new
          page.status = 1
          page.url = @chapter_url + "#p=#{i}"
          page.picture = @javascript.eval("getPicUrl('#{base_path}', '#{file}')")
          page.addHeader "Referer", @chapter_url
          loadedPage i, true, page
          i += 1
        end
        on_page_count.inv true, files.size
      else
        on_page_count.inv false
      end
    end
    @client.start
    @client
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0

    @client = HTTPClient.new page.url
    @client.on_complete = Callback.new do |c|
        if c.getError.length == 0
            doc = XMLDocument.new FileData.new(c.path), 1
            unless @javascript
              @javascript = DuktapeEngine.new
              @javascript.eval 'window=this;'
              @javascript.eval file('lzstring.txt').text
              @javascript.eval file('utils.js').text
            end
            s_node = doc.xpath("//body/script[not(@src)]").first
            @javascript.eval s_node.getContent
            base_path = host_url + @javascript.eval("encodeURI(cInfo.path)")
            files = @javascript.eval "cInfo.files"

            if idx < files.size
              page.status = 1
              page.picture = @javascript.eval("getPicUrl('#{base_path}', '#{files[idx]}')")
              page.addHeader "Referer", page.url
              on_complete.inv true, page
            else
              on_complete.inv false, page
            end

        end
    end
    @client.start
    @client
  end
end
