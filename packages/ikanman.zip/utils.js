function getPicUrl(ser, file) {
 var i=ser+file+"?cid="+cInfo.cid,t;
 for(t in cInfo.sl)i+="&"+t+"="+cInfo.sl[t];
 return i
}
