require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://www.930mh.com'

  def host_url page
    limit = []
    @datas = JSON.parse(file('datas.json').text) unless @datas
    type = settings.find('类型')
    type = 0 unless type
    v = @datas['types'].values[type]
    if v.size > 0
      limit << v
    end
    type = settings.find('地区')
    type = 0 unless type
    v = @datas['areas'].values[type]
    if v.size > 0
      limit << v
    end
    type = settings.find('受众')
    type = 0 unless type
    v = @datas['viewer'].values[type]
    if v.size > 0
      limit << v
    end
    type = settings.find('进度')
    type = 0 unless type
    v = @datas['progress'].values[type]
    if v.size > 0
      limit << v
    end
    arr = []
    arr << limit.join('-') if limit.size > 0
    arr << 'update'
    arr << "#{page+1}"
    "#{HOST_URL}/list/#{arr.join('/')}/"
  end


  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = host_url page
    
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        books = []
        nodes = doc.xpath "//li[@class='list-comic']"
        nodes.each do |node|
          book = Book.new
          url_node = node.xpath("a[@class='comic_img']").first
          book.url = url_node.attr('href')
          book.thumb = url_node.getChild(0).attr('src')
          des_node = node.xpath("span[@class='comic_list_det']").first
          book.name = des_node.attr('title')
          book.subtitle = des_node.xpath('p[1]').first.getContent.gsub('作者：', '').strip
          books << book
        end

        p_nodes = doc.xpath("//ul[@class='pagination']/li[@class='next']")
        no_more = p_nodes.size == 0
        on_complete.inv true, books, no_more
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    url = book.url

    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        des_node = doc.xpath("//p[@class='comic_deCon_d']").first
        book.des = des_node.getContent.strip

        list_nodes = doc.xpath("//*[contains(@id,'chapter-list')]")
        chapters = []
        
        list_nodes.each do |l_node|
          nodes = l_node.xpath('li/a')
          nodes.reverse_each do |node|
            chapter = Chapter.new 
            chapter.url = HOST_URL + node.attr('href')
            chapter.name = node.xpath('span[@class="list_con_zj"]').first.getContent.strip
            chapters << chapter
          end
        end

        on_complete.inv true, book, chapters, false
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete

    url = "#{HOST_URL}/search/?keywords=#{HTTP::URL::encode key}&page=#{page+1}"
    
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        books = []
        nodes = doc.xpath "//li[@class='list-comic']"
        nodes.each do |node|
          book = Book.new
          url_node = node.xpath("a[@class='image-link']").first
          book.url = url_node.attr('href')
          book.thumb = url_node.getChild(0).attr('src')
          book.name = url_node.attr('title')

          book.subtitle = node.xpath('p[2]').first.getContent.strip
          books << book
        end

        p_nodes = doc.xpath("//ul[@class='pagination']/li[@class='next']")
        no_more = p_nodes.size == 0
        on_complete.inv true, books, no_more
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

end
