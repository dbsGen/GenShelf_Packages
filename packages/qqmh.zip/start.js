function getPictures() {
    var rets = [];

    var h = CryptoJS.AES.decrypt(chapterImages, CryptoJS.enc.Utf8.parse('123456781234567G'), {
        iv: CryptoJS.enc.Utf8.parse('ABCDEF1G34123412'),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });
    try {
        chapterImages = JSON.parse(h.toString(CryptoJS.enc.Utf8));

        for (var i = 0, t = chapterImages.length; i < t; ++i) {
            var hosts = SinConf.resHost[0];
            var domain;
            if (typeof hosts.domain === 'string') {
                domain = hosts.domain;
            } else {
                var l = hosts.domain.length;
                var r = Math.floor(Math.random() * l);
                domain = hosts.domain[r];
            }
            rets.push(domain + '/' + chapterPath + chapterImages[i]);
        }
        return rets;
    }catch (e) {
        return [];
    }
}
