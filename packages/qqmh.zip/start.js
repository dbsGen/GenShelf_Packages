function getPictures() {
    var rets = [];
    for (var i = 0, t = chapterImages.length; i < t; ++i) {
        var hosts = SinConf.resHost[0];
        var domain;
        if (typeof hosts.domain === 'string') {
            domain = hosts.domain;
        } else {
            var l = hosts.domain.length;
            var r = Math.floor(Math.random() * l);
            domain = hosts.domain[r];
        }
        rets.push(domain + '/' + chapterPath + chapterImages[i]);
    }
    return rets;
}