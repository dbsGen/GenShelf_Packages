require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  @stop = false

  def process chapter
    @stop = false
    if @javascript 
      load_chapter chapter
    else
      @client = HTTPClient.new 'http://www.930mh.com/js/config.js'
      @client.on_complete = Callback.new do |c| 
        @client = nil
        if c.getError.length == 0
          @javascript = DuktapeEngine.new


          @javascript.eval(file('core.js').text)
          @javascript.eval(file('enc-base64.js').text)
          @javascript.eval(file('cipher-core.js').text)
          @javascript.eval(file('aes.js').text)

          @javascript.eval file('start.js').text

          @javascript.fileEval c.path 

          load_chapter chapter
        else
          on_page_count.inv false
        end
      end
      @client.start
    end
  end

  def load_chapter chapter
    url = chapter.url
    @client = HTTPClient.new url
    @client.read_cache = true
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        s_node = doc.xpath("//body/script[not(@src)]").first
        @javascript.eval s_node.getContent
        ps = @javascript.eval 'getPictures();'

        ps.each_with_index do |p_url, idx|
          page = Page.new
          page.url = url+"#p=#{idx+1}"
          page.picture = p_url
          loadedPage idx, true, page
        end
        on_page_count.inv true, ps.size
      else
        on_page_count.inv false
      end
    end
    @client.start
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    url = page.url
    p url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        s_node = doc.xpath("//body/script[not(@src)]").first
        @javascript.eval s_node.getContent
        ps = @javascript.eval 'getPictures();'

        page = Page.new
        page.url = url
        page.picture = ps[idx]
        loadedPage idx, true, page
        
      else
        loadedPage idx, false, page
      end
    end
    @client.start
  end
end
