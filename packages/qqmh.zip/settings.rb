require 'models'

class Settings < HiEngine::Object
  def process
    begin
      datas = JSON.parse(file('datas.json').text)
      item = SettingItem.new
      item.name = '类型'
      item.type = 1
      item.params = datas['types'].keys
      addItem item

      item = SettingItem.new
      item.name = '地区'
      item.type = 1
      item.params = datas['areas'].keys
      addItem item

      item = SettingItem.new
      item.name = '受众'
      item.type = 1
      item.params = datas['viewer'].keys
      addItem item

      item = SettingItem.new
      item.name = '进度'
      item.type = 1
      item.params = datas['progress'].keys
      addItem item
    rescue Exception => e
      p e

    end
  end
end
