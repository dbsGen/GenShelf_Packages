require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Reader < HiEngine::Object
  HOST_URL = 'http://manhua.fzdm.com/'
  @stop = false
  @chapter_url

  def load_page page, idx
    page.status = 0
    @client = HTTPClient.new page.url
    @client.read_cache = true
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        page.status = 1
        parse_page page, c.path do |url|
          loadedPage idx, true, page
          if url == nil
            self.on_page_count.inv true, idx+1
          else
            np = Page.new
            np.url = url
            load_page np, idx+1
          end
        end
      else
        p "download failed #{c.getError}"
        page.status = -1
        loadedPage idx, false, page
        self.on_page_count.inv false
      end
    end
    @client.start
  end

  def parse_page page, path
    doc = XMLDocument.new FileData.new(path), 1
    node = doc.xpath("//*[@id='mh']").first

    pic = node.xpath('li//img').first.getAttribute('src')
    page.picture = pic['http:'] == nil ? ('http:' + pic) : pic
    next_url = nil
    nodes = node.xpath('li//a')
    next_url = @chapter_url + nodes.first.getAttribute('href') if nodes.size > 0
    yield next_url
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @chapter_url = chapter.url
    @stop = false
    page = Page.new
    page.url = chapter.url
    load_page page, 0
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0
    @client = HTTPClient.new page.url
    @client.read_cache = false
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        page.status = 1
        parse_page page, c.path do |url|
          on_complete.inv true, page
        end
      else
        page.status = -1
        on_complete.inv false, page
      end
    end
    @client.start
  end
end
