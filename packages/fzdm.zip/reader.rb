require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  HOST_URL = 'http://manhua.fzdm.com/'
  @stop = false
  @chapter_url

  def load_page page, idx
    page.status = 0

    @client = HTTPClient.new page.url
    @client.read_cache = true
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        page.status = 1
        parse_page page, c.path do |url|
          loadedPage idx, true, page
          if url == nil
            self.on_page_count.inv true, idx+1
          elsif url == ''
            self.on_page_count.inv false
          else
            np = Page.new
            np.url = url
            load_page np, idx+1
          end
        end
      else
        page.status = -1
        loadedPage idx, false, page
        self.on_page_count.inv false
      end
    end
    @client.start
  end

  def parse_page page, path
    begin
      unless @javascript
        @javascript = DuktapeEngine.new
        @javascript.eval file('pro.js').text
      end
      doc = XMLDocument.new FileData.new(path), 1
      nodes = doc.xpath("//script[not(@src)]")
      node = nodes[nodes.size - 2]
      @javascript.eval node.getContent
      res = @javascript.eval 'html_str'
      n_doc = XMLDocument.new Data::fromString(res), 1
      pic = n_doc.xpath("//img").first.attr 'src'

      page.picture = pic['http:'] == nil ? ('http:' + pic) : pic
      next_url = nil
      last = doc.xpath('//div[@class="navigation"]/a[last()]').first
      if last.getContent == "下一页"
        next_url = @chapter_url + last.getAttribute('href')
        yield next_url
      else
        yield nil
      end
    rescue Exception => e
      p e
      yield ''
    end
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @chapter_url = chapter.url
    @stop = false
    page = Page.new
    page.url = chapter.url
    load_page page, 0
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0
    @client = HTTPClient.new page.url
    @client.read_cache = false
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      return if @stop
      if c.getError.length == 0
        page.status = 1
        parse_page page, c.path do |url|
          if url
            on_complete.inv true, page
          else
            on_complete.inv false, page
          end
        end
      else
        page.status = -1
        on_complete.inv false, page
      end
    end
    @client.start
  end
end
