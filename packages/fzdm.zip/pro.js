var getCookie = function(str) {return '';}
var html_str;
var document = {
    write: function(str) {
    }
}
var $ = function(name) {
    return {
        html: function(str) {
            html_str = str;
        }
    }
}