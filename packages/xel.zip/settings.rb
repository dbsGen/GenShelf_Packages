require 'models'

class Settings < HiEngine::Object
  def process
    begin
      item = SettingItem.new
      item.name = '地址'
      item.type = 1
      item.params = ['xieelian.com', 'xieelao.net']
      addItem item

      item = SettingItem.new
      item.name = '类别'
      item.type = 1
      item.params = JSON.parse(file('types.json').text).keys
      addItem item

    rescue Exception => e
      p e
    end
  end
end
