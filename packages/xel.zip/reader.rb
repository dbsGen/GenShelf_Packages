require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require "duktape"

class Reader < HiEngine::Object
  @stop = false
  @chapter_url

  def servce_num
    ser = settings.find '服务器'
    ser = 0 unless ser
    ser
  end

  def load_page url, idx
    page = Page.new 
    page.url = url
    @client = HTTPClient.new page.url
    p url
    @client.read_cache = true
    @client.retry_count = 3
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        utf8d = Encoder.decode FileData.new(c.path), 'gb2312'
        doc = GBDocument.new utf8d
        p "size #{doc.css('#imgshow').size}"
        img_node = doc.css("#imgshow img").first
        p img_node.attr('src')
        page.picture = img_node.attr('src')
        next_node = doc.css(".pagelist > li:last-child a").first
        next_url = nil
        if next_node.attr('href') != '#'
          next_url = url.gsub(/[^\/]+$/, next_node.attr('href'))
        end
        
        yield page, true, next_url
      else
        yield page, false, nil
      end
    end
    @client.start
  end

  def load_p url, idx
    load_page url, idx do |page, res, next_url| 
      if res
        loadedPage idx, true, page
        if next_url
          load_p next_url, idx + 1
        else
          on_page_count.inv true, idx + 1
        end
      else
        loadedPage idx, false, page
        on_page_count.inv false
      end
    end
  end

  # 开始解析一个章节，读取其中所有的页
  def process chapter
    @stop = false
    load_p chapter.url, 0
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    @stop = false
    page.status = 0
    load_page page.url, idx do |page, res, next_url| 
      if res
        on_complete.inv true, page
      else
        on_complete.inv false, page
      end
    end
  end
end
