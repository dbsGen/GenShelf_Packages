require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'http://www.xieelao.com'

  def main_url page
    unless @types
      @types = JSON.parse(file('types.json').text).values
    end
    type = settings.find '类别'
    type = 0 unless type
    t = @types[type]
    "#{HOST_URL}/#{t['t']}/list_#{t['n']}_#{page+1}.html"
  end

  # @description 加载主页接口。
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = main_url(page)
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        doc = XMLDocument.new FileData.new(c.path), 1
        nodes = doc.xpath("//ul[contains(@class, 'piclist')]/li/a")
        books = []
        nodes.each do |node|
          book = Book.new
          book.url = HOST_URL + node.attr('href')
          book.name = node.getChild(0).getContent
          book.subtitle = book.name
          book.thumb = node.getChild(2).attr('xsrc')
          books << book
        end
        on_complete.inv true, books
      else
        on_complete.inv false
      end
    end
    client.start
    client
  end

  # @description 读去书本详细信息的接口。
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    if page == 0
      chapter = Chapter.new
      chapter.url = book.url
      chapter.name = "Chapter 1"
      on_complete.inv true, book, [chapter], false
    else
      on_complete.inv true, book, [], false
    end
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    on_complete.inv false
  end

end
