require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'gumbo'

class Library < HiEngine::Object

  HOST_URL = 'http://hcomic.cc'

  def host_url page
    unless @types
      data = JSON.parse(file('datas.json').text)
      @types = data['types'].values
    end

    type = @types[settings.find('类型') || 0]
    c = if type.size > 0 then "/category/#{type}" else "" end

    "#{HOST_URL}#{c}/list/#{page+1}.html"
  end

  def parse_page path
    doc = GBDocument.new FileData.new(path)
    books = []
    nodes = doc.css "#article-list .article"
    
    nodes.each do |node|
      link_node = node.css(".thumbnail a").first
      book = Book.new
      book.url = link_node.attr('href')
      image_node = link_node.css('img').first
      book.thumb = image_node.attr('src')
      book.name = image_node.attr('alt')
      book.subtitle = book.name
      books << book
    end
    yield books
  end

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = host_url page

    p url
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        parse_page c.path do |books|
          on_complete.inv true, books
        end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    chapter = Chapter.new
    chapter.url = book.url
    chapter.name = "Chapter"

    on_complete.inv true, book, [chapter], false
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete
    url = "#{HOST_URL}/Search/index/?kw=#{HTTP::URL::encode key}&submit=&p=#{page+1}"

    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        parse_page c.path do |books|
          on_complete.inv true, books
        end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

end
