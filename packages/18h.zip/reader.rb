require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'gumbo'
require 'duktape'

class Reader < HiEngine::Object
  @stop = false

  def load_page url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        doc = GBDocument.new FileData.new(c.path)
        s_node = doc.css(".centent-article img").first

        page = Page.new
        page.url = url
        page.picture = s_node.attr('src')
        next_node = doc.css(".centent-article > a").first
        if next_node
          yield page, next_node.attr('href')
        else
          yield page, nil
        end
      else
        yield nil
      end
    end
    @client.start
    @client
  end

  def load_foward url, idx = 0
    load_page url do |page, n_url|
      loadedPage idx, true, page
      if n_url
        load_foward n_url, idx + 1
      else
        on_page_count.inv true, idx+1
      end
    end
  end

  def process chapter
    @stop = false
    
    load_foward chapter.url
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    url = page.url

    load_page url do |page, n_url|
      loadedPage idx, true, page
    end
  end
end
