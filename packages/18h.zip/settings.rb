require 'models'

class Settings < HiEngine::Object
  def process
    begin
      datas = JSON.parse(file('datas.json').text)
      item = SettingItem.new
      item.name = '类型'
      item.type = 1
      item.params = datas['types'].keys
      addItem item
    rescue Exception => e
      p e

    end
  end
end
