var N = {
    reader: function(obj) {
        this.target = obj;
        this.set_page = function(n, p) {
        };
        this.pages = function() {
            var host = this.target.media_url;
            var id = this.target.gallery.media_id;
            var images = this.target.gallery.images.pages;
            var res = [];
            for (var i = 0, t = images.length; i < t; ++i) {
                var type = images[i].t;
                if (type == 'j') {
                    type = '.jpg';
                }else if (type == 'p') {
                    type = '.png';
                }else if (type == 'g') {
                    type = '.gif';
                }
                res.push(host+'galleries/'+id+'/'+(i+1)+type);
            }
            return res;
        }
    }
};