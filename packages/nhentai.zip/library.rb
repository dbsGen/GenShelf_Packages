require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'

class Library < HiEngine::Object

  HOST_URL = 'https://nhentai.net'

  def parse path
    doc = XMLDocument.new FileData.new(path), 1
    books = []
    nodes = doc.xpath "//*[@class='gallery']"
    nodes.each do |node|
      book = Book.new
      link_node = node.xpath('a').first
      book.url = HOST_URL + link_node.attr('href')
      image_node = link_node.xpath('img').first
      book.thumb = image_node.attr('data-src')
      book.thumb = image_node.attr('src') if book.thumb == nil || book.thumb.size == 0
      book.thumb = book.thumb.gsub(/^\/\//, 'https://')
      des_node = link_node.xpath("*[@class='caption']").first
      book.name = des_node.getContent.strip
      books << book
    end

    p_nodes = doc.xpath("//*[@class='pagination']/a[@class='next']")
    no_more = p_nodes.size == 0
    yield true, books, no_more
  end

  # 加载主页接口。
  # @method load
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  #   不过这个client并不是关键要素，所以有一串请求时也不必担心，返回最开始的一个就行。
  def load page, on_complete
    url = "#{HOST_URL}/?page=#{page+1}"
    
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
      	parse c.path do |success, books, no_more|
        	on_complete.inv success, books, no_more
      	end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

  # 读去书本详细信息的接口。
  # @method loadBook
  # @param book Book对象
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, new_book(Book), chapters([Chapter...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def loadBook book, page, on_complete
    chapter = Chapter.new 
    chapter.url = book.url + '1/'
    chapter.name = "Chapter"

    on_complete.inv true, book, [chapter], false
  end

  # @description 搜索接口
  # @param key 搜索关键字
  # @param page 分页，从0开始
  # @param on_complete 结束回调
  # => 成功: on_complete.inv true, books([Book...]), no_more(bool)
  # => 失败: on_complete.inv false
  # @return client 把请求反回，让主程序页面退出的时候有能力结束请求。
  def search key, page, on_complete

    url = "#{HOST_URL}/search/?q=#{HTTP::URL::encode key}&page=#{page+1}"
    
    client = HTTPClient.new url
    client.on_complete = Callback.new do |c|
      if c.getError.length == 0
        parse c.path do |success, books, no_more|
        	on_complete.inv success, books, no_more
        end
      else
        on_complete.invoke [false]
      end
    end
    client.start
    client

  end

end
