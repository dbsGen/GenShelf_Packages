require 'models'

class Settings < HiEngine::Object
  def process
  end
end
