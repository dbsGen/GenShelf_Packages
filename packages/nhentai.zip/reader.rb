require 'object'
require 'models'
require 'http_client'
require 'callback'
require 'data'
require 'xml'
require 'duktape'

class Reader < HiEngine::Object
  @stop = false

  def process chapter
    @stop = false

    url = chapter.url
    @client = HTTPClient.new url
    @client.read_cache = true
    @client.on_complete = Callback.new do |c| 
      @client = nil
      if c.getError.length == 0
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval file('start.js').text
        end

        doc = XMLDocument.new FileData.new(c.path), 1
        s_node = doc.xpath("//body/script[last()]").first

        @javascript.eval s_node.getContent
        ps = @javascript.eval('reader.pages();')

        ps.each_with_index do |p_url, idx|
          page = Page.new
          page.url = url.gsub(/\d+(?=\/$)/, (idx+1).to_s)
          page.picture = p_url
          loadedPage idx, true, page
        end

        on_page_count.inv true, ps.size
      else
        on_page_count.inv false
      end
    end
    @client.start
  end

  def stop
    @stop = true
    if @client
      @client.cancel
    end
  end

  def reloadPage page, idx, on_complete
    url = page.url
    @client = HTTPClient.new url
    @client.on_complete = Callback.new do |c|
      @client = nil
      if c.getError.length == 0
        unless @javascript
          @javascript = DuktapeEngine.new
          @javascript.eval file('start.js').text
        end

        doc = XMLDocument.new FileData.new(c.path), 1
        s_node = doc.xpath("//body/script[last()]").first
        @javascript.eval s_node.getContent
        ps = @javascript.eval('reader.pages();')

        page = Page.new
        page.url = url
        page.picture = ps[idx]
        loadedPage idx, true, page
      else
        loadedPage idx, false, page
      end
    end
    @client.start
  end
end
